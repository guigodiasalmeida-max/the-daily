document.addEventListener('DOMContentLoaded',()=>{
  const form=document.getElementById('authForm'),email=document.getElementById('email'),code=document.getElementById('code'),wrap=document.getElementById('codeWrap'),btn=document.getElementById('sendCode'),status=document.getElementById('authStatus');
  let sent=false; const client=tdaClient?.();
  if(!client){status.textContent='Configure o Supabase em config.js para ativar o envio real de e-mail.';btn.disabled=true;return;}
  client.auth.getSession().then(({data})=>{if(data.session){syncCurrentProfile().then(()=>location.href='perfil.html');}});
  form.addEventListener('submit',async e=>{
    e.preventDefault(); const em=email.value.trim().toLowerCase();
    if(!sent){
      status.textContent='Enviando código de verificação...'; btn.disabled=true;
      const {error}=await client.auth.signInWithOtp({email:em,options:{shouldCreateUser:true}});
      btn.disabled=false;
      if(error){status.textContent=error.message;return;}
      sent=true;wrap.hidden=false;btn.textContent='Verificar e-mail';status.textContent='Código enviado. Confira sua caixa de entrada e o spam.';code.focus();return;
    }
    const c=code.value.trim(); if(!c)return;
    status.textContent='Verificando...';btn.disabled=true;
    const {data,error}=await client.auth.verifyOtp({email:em,token:c,type:'email'});
    if(error){btn.disabled=false;status.textContent='Código inválido ou expirado. Solicite outro código.';return;}
    const u=data.user;
    let profile={id:u.id,email:em,name:em.split('@')[0],username:em.split('@')[0].replace(/[^a-z0-9_]/g,'').slice(0,30)||'usuario',bio:'Escrevo coisas que nunca aconteceram.',avatar:'📰',avatar_url:'',verified:!!u.email_confirmed_at};
    const existing=await client.from('profiles').select('*').eq('id',u.id).maybeSingle();
    if(existing.data) profile={...profile,name:existing.data.name,username:existing.data.username,bio:existing.data.bio||'',avatar_url:existing.data.avatar_url||'',avatar:existing.data.avatar_url||'📰',joined:existing.data.joined_at};
    else await client.from('profiles').insert({id:u.id,name:profile.name,username:profile.username,bio:profile.bio});
    setCurrentUser(profile); await syncCurrentProfile(); status.textContent='E-mail verificado. Entrando...'; location.href='perfil.html';
  });
});
