/* Supabase client compartilhado */
(function(){
  const cfg=window.TDA_CONFIG||{};
  window.TDA_SUPABASE=null;
  if(window.supabase && cfg.supabaseUrl && cfg.supabaseAnonKey && !String(cfg.supabaseUrl).includes('SEU-PROJETO') && !String(cfg.supabaseAnonKey).includes('SUA_ANON')){
    try{ window.TDA_SUPABASE=window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey); }catch(e){ console.error('Supabase:',e); }
  }
  window.getTdaSupabase=()=>window.TDA_SUPABASE;
})();
