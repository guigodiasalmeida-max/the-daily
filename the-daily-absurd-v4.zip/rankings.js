document.addEventListener('DOMContentLoaded',()=>{
 const users=getUsers(), arts=allNews();
 const data=[
  ['📝 Mais Publicações',users.map(u=>({label:'@'+u.username,value:arts.filter(a=>a.authorUsername===u.username||a.author===u.name).length})).sort((a,b)=>b.value-a.value)],
  ['❤️ Mais Curtidas',users.map(u=>({label:'@'+u.username,value:arts.filter(a=>a.authorUsername===u.username||a.author===u.name).reduce((n,a)=>n+(a.likes||0),0)})).sort((a,b)=>b.value-a.value)],
  ['👥 Mais Seguidos',users.map(u=>({label:'@'+u.username,value:getFollows().filter(f=>f.type==='user'&&f.target===u.id).length||u.followers||0})).sort((a,b)=>b.value-a.value)],
  ['🧠 Mais Criativos',users.map(u=>({label:'@'+u.username,value:(u.publications||0)*17+(u.likes||0)%100})).sort((a,b)=>b.value-a.value)],
  ['🔥 Em Alta',hotNews().slice(0,5).map(a=>({label:a.title,value:Math.round(hotScore(a))}))]
 ];
 document.getElementById('rankings').innerHTML=data.map(([title,list])=>`<section class="box ranking-panel"><div class="box-title">${title}</div><ol class="ranking">${list.slice(0,5).map((x,i)=>`<li><span>${String(i+1).padStart(2,'0')}</span><div><b>${esc(x.label)}</b><small>${x.value}</small></div></li>`).join('')}</ol></section>`).join('');
});
