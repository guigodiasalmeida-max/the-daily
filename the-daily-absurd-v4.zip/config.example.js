window.TDA_CONFIG={supabaseUrl:'https://SEU-PROJETO.supabase.co',supabaseAnonKey:'SUA_ANON_PUBLIC_KEY'};
