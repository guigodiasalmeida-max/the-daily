document.addEventListener('DOMContentLoaded',async()=>{
  const root=document.getElementById('profile'); let me=await syncCurrentProfile();
  const q=new URLSearchParams(location.search).get('u');
  let u=q?(findUserByUsername(q)||me):me;
  if(!u){root.innerHTML='<div class="notice">Você ainda não entrou. <a href="auth.html">Entrar / criar conta</a></div>';return;}
  const isMine=!!me&&u.id===me.id;
  await render();

  async function render(){
    const arts=userArticles(u.username), follows=getFollows().filter(x=>x.type==='user'&&x.target===u.id).length;
    const liked=arts.reduce((n,a)=>n+(a.likes||0),0);
    root.innerHTML=`<section class="profile-hero"><div class="avatar profile-avatar">${u.avatar_url?safeAvatarImg(u.avatar_url,u.name):esc(u.avatar||'📰')}</div><div class="profile-main"><div class="category">ESCRITOR</div><h1>${esc(u.name)}</h1><p class="handle">@${esc(u.username)} ${u.verified?'• ✓ e-mail verificado':''}</p><p>${esc(u.bio||'')}</p><p class="meta">${u.joined?'Entrou em '+esc(u.joined)+' • ':''}${arts.length} publicações • ${liked||u.likes||0} curtidas recebidas • ${follows||u.followers||0} seguidores</p><div class="profile-buttons">${isMine?'<button id="editProfile" class="button">Editar perfil</button><a class="button" href="publicar.html">＋ Publicar</a>':'<button id="follow" class="button">'+(isFollowing('user',u.id)?'Deixar de seguir':'+ Seguir')+'</button>'}</div></div></section>
    ${isMine?`<section id="profileEditor" class="profile-editor" hidden><h2>Editar perfil</h2><form id="profileForm" class="editor"><label>Nome <span>*</span><input id="profileName" maxlength="60" required value="${esc(u.name)}"></label><label>@Usuário <span>*</span><input id="profileUsername" maxlength="30" pattern="[A-Za-z0-9_]+" required value="${esc(u.username)}"><small>Use apenas letras, números e _. O @ não é digitado.</small></label><label>Bio<textarea id="profileBio" maxlength="240">${esc(u.bio||'')}</textarea></label><label>Foto de perfil<input id="profilePhoto" type="file" accept="image/png,image/jpeg,image/webp"><small>PNG, JPG ou WebP. No Supabase, a foto fica salva na conta.</small></label><div id="photoPreview" class="avatar-preview">${u.avatar_url?safeAvatarImg(u.avatar_url,u.name):esc(u.avatar||'📰')}</div><button class="button big" type="submit">Salvar alterações</button><p id="profileStatus" class="status"></p></form></section>`:''}
    <section class="profile-stats"><div><b>${arts.length}</b><span>Publicações</span></div><div><b>${liked||u.likes||0}</b><span>Curtidas</span></div><div><b>${follows||u.followers||0}</b><span>Seguidores</span></div></section>
    <section class="section-head"><h2>${isMine?'Minhas publicações':'Publicações'}</h2></section><div class="news-grid">${arts.length?arts.map(x=>newsCardHTML(x,isMine)).join(''):'<div class="notice">Você ainda não publicou nada. <a href="publicar.html">Criar primeira publicação</a></div>'}</div>`;
    if(isMine) setupEditor(); else document.getElementById('follow')?.addEventListener('click',()=>{const on=toggleFollow('user',u.id);document.getElementById('follow').textContent=on?'Deixar de seguir':'+ Seguir';});
    if(isMine) document.querySelectorAll('[data-delete-article]').forEach(btn=>btn.addEventListener('click',async()=>{
      const item=arts.find(x=>x.id===btn.dataset.deleteArticle); if(!item)return;
      if(!confirm('Apagar esta publicação? Essa ação não pode ser desfeita.'))return;
      btn.disabled=true; btn.textContent='Apagando...'; const result=await deleteArticleEverywhere(item);
      if(!result.ok){btn.disabled=false;btn.textContent='Apagar';showToast(result.error||'Não foi possível apagar.');return;}
      const users=readJSON('tdaUsers',[]),i=users.findIndex(x=>x.id===me.id);if(i>=0){users[i].publications=Math.max(0,(users[i].publications||0)-1);writeJSON('tdaUsers',users);setCurrentUser(users[i]);me=users[i];u=me;}
      showToast('Publicação apagada.'); await render();
    }));
  }

  function setupEditor(){
    const edit=document.getElementById('editProfile'), panel=document.getElementById('profileEditor'); edit?.addEventListener('click',()=>{panel.hidden=!panel.hidden; if(!panel.hidden)document.getElementById('profileName').focus();});
    const file=document.getElementById('profilePhoto'); file?.addEventListener('change',()=>{const f=file.files?.[0];if(!f)return;if(f.size>2*1024*1024){file.value='';showToast('A foto deve ter no máximo 2 MB.');return;}const r=new FileReader();r.onload=()=>document.getElementById('photoPreview').innerHTML=safeAvatarImg(r.result,u.name);r.readAsDataURL(f);});
    document.getElementById('profileForm')?.addEventListener('submit',saveProfile);
  }
  async function saveProfile(e){
    e.preventDefault(); const status=document.getElementById('profileStatus'), name=document.getElementById('profileName').value.trim(), username=document.getElementById('profileUsername').value.trim().toLowerCase(), bio=document.getElementById('profileBio').value.trim(), file=document.getElementById('profilePhoto').files?.[0];
    if(!/^[a-z0-9_]{3,30}$/.test(username)){status.textContent='O @usuário precisa ter de 3 a 30 caracteres: letras, números ou _. ';return;}
    const taken=findUserByUsername(username); if(taken&&taken.id!==u.id){status.textContent='Esse @usuário já está em uso.';return;}
    status.textContent='Salvando...'; let avatar_url=u.avatar_url||''; const client=tdaClient();
    if(file&&client){const ext=(file.name.split('.').pop()||'jpg').toLowerCase(),path=`${u.id}/avatar.${ext}`;const up=await client.storage.from('avatars').upload(path,file,{upsert:true,contentType:file.type});if(up.error){status.textContent='Não foi possível enviar a foto: '+up.error.message;return;}avatar_url=client.storage.from('avatars').getPublicUrl(path).data.publicUrl;}
    else if(file){const r=new FileReader();avatar_url=await new Promise(resolve=>{r.onload=()=>resolve(r.result);r.readAsDataURL(file);});}
    const oldUsername=u.username;
    const updated={...u,name,username,bio,avatar_url,avatar:avatar_url||u.avatar||'📰'};
    if(client){const result=await upsertProfileRemote(updated);if(!result.ok){status.textContent=result.error;return;}}
    const users=readJSON('tdaUsers',[]),i=users.findIndex(x=>x.id===u.id);if(i>=0)users[i]=updated;else users.push(updated);writeJSON('tdaUsers',users);setCurrentUser(updated);u=updated;me=updated;
    const comm=getCommunity().map(a=>a.authorUsername===oldUsername?{...a,author:u.name,authorUsername:u.username,authorId:u.id}:a);saveCommunity(comm);
    status.textContent='Perfil atualizado com sucesso.';showToast('Perfil atualizado.');await render();
  }
});
function safeAvatarImg(url,alt){return `<img class="avatar-img" src="${esc(safeUrl(url))}" alt="Foto de ${esc(alt)}" loading="lazy">`;}
function newsCardHTML(x,owner=false){const img=safeUrl(x.image);return `<article class="card">${img?`<img class="card-img" src="${esc(img)}" alt="${esc(x.title)}" loading="lazy">`:''}<div class="badge">${esc(x.category)} • FICÇÃO</div><h3><a href="artigo.html?id=${encodeURIComponent(x.id)}">${esc(x.title)}</a></h3><p>${esc(x.subtitle||'')}</p><div class="meta">Por ${esc(x.author||'Redação')} • ${esc(x.date||'')} • 👁 ${x.views||0} • ♥ ${x.likes||0}</div>${owner?`<div class="card-actions"><a class="button small" href="artigo.html?id=${encodeURIComponent(x.id)}">Ver</a><button class="report-btn" data-delete-article="${esc(x.id)}">Apagar</button></div>`:''}</article>`;}
