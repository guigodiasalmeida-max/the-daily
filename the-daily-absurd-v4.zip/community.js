document.addEventListener("DOMContentLoaded", ()=>{
  const grid=document.getElementById("communityGrid");
  if(!grid) return;
  const count=document.getElementById("communityCount");
  const searchInput=document.getElementById("searchInput");
  const categorySelect=document.getElementById("categoryFilter");

  function list(){
    const all=allNews().filter(x=>x.isCommunity);
    const q=(searchInput?.value||"").trim().toLowerCase();
    const cat=categorySelect?.value||"";
    return all.filter(x=>
      (!q || x.title.toLowerCase().includes(q) || (x.subtitle||"").toLowerCase().includes(q)) &&
      (!cat || x.category===cat)
    );
  }

  function draw(){
    const items=list();
    count.textContent=`${items.length} publicação${items.length===1?"":"ões"}`;
    if(!items.length){
      grid.innerHTML=`<div class="notice">Nenhuma notícia da comunidade encontrada. Seja o primeiro jornalista do absurdo.</div>`;
      return;
    }
    grid.innerHTML=items.map(x=>{
      const img=safeUrl(x.image);
      const liked=getLikedByMe().includes(x.id);
      return `<article class="community-card">
        ${img?`<img class="card-img" src="${esc(img)}" alt="${esc(x.title)}" loading="lazy">`:""}
        <div class="badge">${esc(x.category)} • FICÇÃO</div>
        <h2><a href="artigo.html?id=${encodeURIComponent(x.id)}">${esc(x.title)}</a></h2>
        <p>${esc(x.subtitle||x.body.slice(0,180))}</p>
        <div class="stats">
          <button class="like-btn" type="button" data-id="${esc(x.id)}" aria-pressed="${liked}">♥ <span>${x.likes||0}</span></button>
          <span>👁 ${x.views||0}</span>
          <span>Por ${esc(x.author)} • ${esc(x.date)}</span>
          <button class="report-btn" type="button" data-id="${esc(x.id)}">Denunciar</button>
        </div>
      </article>`;
    }).join("");
  }

  grid.addEventListener("click", e=>{
    const likeBtn=e.target.closest(".like-btn");
    if(likeBtn){
      const {liked, count:c}=toggleLike(likeBtn.dataset.id);
      likeBtn.setAttribute("aria-pressed", String(liked));
      likeBtn.querySelector("span").textContent=c;
      return;
    }
    const reportBtn=e.target.closest(".report-btn");
    if(reportBtn){
      const n=reportArticle(reportBtn.dataset.id);
      reportBtn.textContent = n>=3 ? "Denunciada" : "Denunciado";
      reportBtn.disabled=true;
      if(n>=3) setTimeout(draw, 600);
    }
  });

  searchInput?.addEventListener("input", draw);
  setupCategoryFilter(categorySelect, draw);
  draw();
});
