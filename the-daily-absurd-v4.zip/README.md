# The Daily Absurd — versão aprimorada

Esta versão mantém as funções existentes e melhora a área de conta/perfil.

## O que foi melhorado
- Login real por código enviado por e-mail usando Supabase Auth.
- A conta só entra depois da verificação do código recebido.
- Perfil editável: nome, @usuário e bio.
- Foto de perfil com upload real para o Storage do Supabase (até 2 MB).
- Página do próprio perfil mostra claramente **Minhas publicações**.
- Cada publicação do usuário tem botão **Apagar**.
- A exclusão remove a publicação local e, quando criada no Supabase, também remove o registro remoto.
- Publicações novas são sincronizadas com a tabela `articles` quando o Supabase está configurado.
- O nome do autor usado na publicação vem do perfil logado.

## Configuração obrigatória para conta real
1. Crie um projeto no Supabase.
2. Em Authentication > Providers, habilite Email.
3. Configure o SMTP/e-mail do projeto se quiser entrega de e-mail personalizada; o Supabase também pode usar o serviço de e-mail padrão conforme os limites do projeto.
4. No arquivo `config.js`, coloque a URL do projeto e a chave pública (anon).
5. Execute todo o `supabase.sql` no SQL Editor.
6. Abra o projeto com VS Code + Live Server.

**Nunca coloque a service_role key no navegador.** Use somente a chave pública/anon.

## Observação
A interface continua com os dados locais já existentes para preservar o conteúdo da versão anterior. As funções novas de conta, foto, publicação e exclusão usam o Supabase quando ele está configurado.
