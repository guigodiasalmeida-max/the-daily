/* ===================== THE DAILY ABSURD — núcleo ===================== */

const CATEGORIES = ["Mundo","Brasil","Ciência","Tecnologia","Esportes","Cultura","Cidade","Economia","Outros"];

const seedNews=[
{id:"santa",category:"Mundo",title:"Papai Noel é detido após tentativa de assalto a banco na Groenlândia",subtitle:"Duende que acompanhava o suspeito fugiu pilotando uma motocicleta movida a bateria de servos.",author:"Redação do Absurd",image:""},
{id:"pombos",category:"Ciência",title:"Cientistas descobrem que pombos realizam reuniões secretas nas praças",subtitle:"Pesquisadores dizem ter encontrado uma pauta intitulada “humanos: problemas e soluções”.",author:"Redação do Absurd",image:""},
{id:"geladeira",category:"Cidade",title:"Homem processa a própria geladeira após ela “olhar torto” para ele",subtitle:"Defesa afirma que o eletrodoméstico se recusou a comentar o caso.",author:"Redação do Absurd",image:""},
{id:"farofa",category:"Ciência",title:"NASA confirma existência de planeta feito inteiramente de farofa",subtitle:"Agência espacial admite que ainda não sabe como a farofa chegou ao espaço.",author:"Redação do Absurd",image:""},
{id:"semaforo",category:"Brasil",title:"Prefeitura inaugura semáforo que dá conselhos amorosos",subtitle:"No vermelho, equipamento pede reflexão. No verde, manda seguir em frente.",author:"Redação do Absurd",image:""},
{id:"sindico",category:"Brasil",title:"Cachorro é eleito síndico e já multou três gatos",subtitle:"Novo gestor prometeu instalar mais postes e acabar com a bagunça no estacionamento.",author:"Redação do Absurd",image:""},
{id:"moeda",category:"Economia",title:"Banco Central anuncia moeda oficial de 73 centavos",subtitle:"Nova cédula terá um desenho de uma pessoa tentando encontrar o troco.",author:"Redação do Absurd",image:""},
{id:"porta",category:"Mundo",title:"Brasil descobre cidade onde todas as portas dão no mesmo quarto",subtitle:"Moradores dizem que o problema começou depois de uma reforma feita em 1987.",author:"Redação do Absurd",image:""},
{id:"reuniao",category:"Tecnologia",title:"Computador pede férias após passar 14 minutos processando um PDF",subtitle:"Máquina afirma que “não nasceu para isso”.",author:"Redação do Absurd",image:""},
{id:"oceano",category:"Ciência",title:"Oceanógrafos encontram peixe que sabe dizer “bom dia” em oito idiomas",subtitle:"O animal, entretanto, se recusa a responder perguntas depois das 18h.",author:"Redação do Absurd",image:""}
];



const SEED_USERS = [
 {id:'u-pombo',name:'PomboNews',username:'pombonews',bio:'Escrevo notícias que jamais aconteceram.',joined:'01 de setembro de 2026',publications:3,likes:842,followers:238,avatar:'🐦'},
 {id:'u-caio',name:'Caio Absurdista',username:'caioabsurdista',bio:'Jornalismo sério, fatos inexistentes.',joined:'02 de setembro de 2026',publications:2,likes:791,followers:191,avatar:'📰'},
 {id:'u-noticia',name:'Notícia Doida',username:'noticiadoida',bio:'Tudo é notícia quando a realidade desiste.',joined:'04 de setembro de 2026',publications:2,likes:744,followers:173,avatar:'🤪'}
];
const SEED_PUBLISHERS = [
 {id:'pub-absurd',name:'Absurd Press',username:'absurdpress',description:'A editora que publica o impossível com absoluta convicção.',logo:'🟣',followers:1120,writers:18,publications:67,awards:['Editora da Semana — 2x'],owner:'u-pombo'},
 {id:'pub-pombo',name:'Pombo News',username:'pombonews',description:'Informação confiável segundo três pombos e um banco de praça.',logo:'🐦',followers:680,writers:7,publications:21,awards:[],owner:'u-pombo'}
];
function getUsers(){const a=readJSON('tdaUsers',[]);return [...SEED_USERS,...(Array.isArray(a)?a:[])];}
function getPublishers(){const a=readJSON('tdaPublishers',[]);return [...SEED_PUBLISHERS,...(Array.isArray(a)?a:[])];}
function getMemberships(){return readJSON('tdaMemberships',[]);}
function getFollows(){return readJSON('tdaFollows',[]);}
function currentUser(){return readJSON('tdaCurrentUser',null);}
function setCurrentUser(u){writeJSON('tdaCurrentUser',u);}
async function logoutUser(){try{const client=tdaClient();if(client)await client.auth.signOut();}catch{} localStorage.removeItem('tdaCurrentUser');}
function findUserByUsername(u){return getUsers().find(x=>x.username.toLowerCase()===String(u).replace(/^@/,'').toLowerCase());}
function findPublisherByUsername(u){return getPublishers().find(x=>x.username.toLowerCase()===String(u).replace(/^@/,'').toLowerCase());}
function userArticles(username){return allNews().filter(x=>String(x.authorUsername||'').toLowerCase()===String(username).toLowerCase() || String(x.author||'').toLowerCase()===String(username).toLowerCase());}
function toggleFollow(type,target){const me=currentUser();if(!me){showToast('Entre na sua conta para seguir.');return false;}const f=getFollows(),idx=f.findIndex(x=>x.follower===me.id&&x.type===type&&x.target===target);if(idx>=0){f.splice(idx,1);writeJSON('tdaFollows',f);return false;}f.push({follower:me.id,type,target,date:new Date().toISOString()});writeJSON('tdaFollows',f);return true;}
function isFollowing(type,target){const me=currentUser();return !!me&&getFollows().some(x=>x.follower===me.id&&x.type===type&&x.target===target);}
function notify(message){const n=readJSON('tdaNotifications',[]);n.unshift({id:Date.now()+Math.random(),message,read:false,date:new Date().toISOString()});writeJSON('tdaNotifications',n.slice(0,100));}
function getNotifications(){return readJSON('tdaNotifications',[]);}
function awardData(){return readJSON('tdaAwards', {writers:[],publishers:[],prizes:[],history:[]});}
function weekKey(d=new Date()){const x=new Date(d);x.setHours(0,0,0,0);const day=(x.getDay()+6)%7;x.setDate(x.getDate()-day);return x.toISOString().slice(0,10);}
function weeklyWriterRanking(){const users=getUsers();const all=allNews();return users.map(u=>({user:u,score:all.filter(a=>a.authorUsername===u.username||a.author===u.name).reduce((n,a)=>n+(a.likes||0),0)})).sort((a,b)=>b.score-a.score);}
function hotScore(x){const age=Math.max(1,(Date.now()-new Date(x.createdISO||Date.now()).getTime())/3600000);return ((x.likes||0)*4+(x.comments||0)*2+(x.shares||0)*3+1)/(Math.pow(age,0.7));}
function hotNews(){return allNews().sort((a,b)=>hotScore(b)-hotScore(a));}
function showToast(message){const t=document.getElementById('toast');if(!t){alert(message);return;}t.textContent=message;t.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.classList.remove('show'),2600);}
function setupAccountUI(){
 document.querySelectorAll('[data-account-link]').forEach(a=>{const u=currentUser();a.textContent=u?`@${u.username} • Sair`:'Entrar / Criar conta';a.href=u?'#':'auth.html';if(u)a.onclick=e=>{e.preventDefault();logoutUser();location.reload();};});
}

/* ---------- storage seguro (nunca deixa dado corrompido quebrar o site) ---------- */
function readJSON(key,fallback){
  try{ const raw=localStorage.getItem(key); if(!raw) return fallback; const parsed=JSON.parse(raw); return parsed==null?fallback:parsed; }
  catch{ return fallback; }
}
function writeJSON(key,value){
  try{ localStorage.setItem(key,JSON.stringify(value)); return true; } catch{ return false; }
}

function getCommunity(){
  const arr=readJSON("tdaCommunity",[]);
  return Array.isArray(arr) ? arr.filter(x=>x && typeof x.title==="string" && typeof x.body==="string") : [];
}
function saveCommunity(arr){ writeJSON("tdaCommunity", arr.slice(0,300)); }

function getViews(){ return readJSON("tdaViews",{}); }
function bumpView(id){ const v=getViews(); v[id]=(v[id]||0)+1; writeJSON("tdaViews",v); return v[id]; }

function getLikeCounts(){ return readJSON("tdaLikeCounts",{}); }
function getLikedByMe(){ return readJSON("tdaLikedByMe",[]); }
function toggleLike(id){
  const me=currentUser();
  if(!me){showToast('Entre na sua conta para curtir.');return {liked:false,count:getLikeCounts()[id]||0,blocked:true};}
  const counts=getLikeCounts(), mine=getLikedByMe(), key=`${me.id}:${id}`, already=mine.includes(key)||mine.includes(id);
  if(already){counts[id]=Math.max(0,(counts[id]||1)-1);writeJSON('tdaLikedByMe',mine.filter(x=>x!==key&&x!==id));}
  else{counts[id]=(counts[id]||0)+1;mine.push(key);writeJSON('tdaLikedByMe',mine);notify(`Você curtiu uma publicação.`);}
  writeJSON('tdaLikeCounts',counts);return {liked:!already,count:counts[id]};
}

function getComments(id){ const all=readJSON("tdaComments",{}); return Array.isArray(all[id]) ? all[id] : []; }
function addComment(id,comment){
  const all=readJSON("tdaComments",{});
  const list=Array.isArray(all[id]) ? all[id] : [];
  list.push(comment);
  all[id]=list.slice(-100);
  writeJSON("tdaComments", all);
}

function getReportCount(id){ const r=readJSON("tdaReports",{}); return r[id]||0; }
function reportArticle(id){
  const mine=readJSON("tdaReportedByMe",[]);
  if(mine.includes(id)) return getReportCount(id);
  const r=readJSON("tdaReports",{});
  r[id]=(r[id]||0)+1;
  writeJSON("tdaReports", r);
  mine.push(id); writeJSON("tdaReportedByMe", mine);
  return r[id];
}

/* ---------- montagem dos dados ---------- */
function allNews(){
  const community=getCommunity()
    .map((x,i)=>({...x,id:x.id||"community-"+i,isCommunity:true,authorUsername:x.authorUsername||'',createdISO:x.createdISO||new Date().toISOString()}))
    .filter(x=>getReportCount(x.id) < 3); // some da listagem após 3 denúncias (moderação simulada no navegador)
  const seed=seedNews.map(x=>({...x}));
  const views=getViews(), likes=getLikeCounts();
  return [...community, ...seed].map(x=>({...x, views:views[x.id]||0, likes:likes[x.id]||0}));
}
function rankedNews(){
  return [...allNews()].sort((a,b)=> (b.views + b.likes*3) - (a.views + a.likes*3));
}

function esc(s){ return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m])); }
function safeUrl(u){
  if(!u) return "";
  try{ const url=new URL(u, location.href); return (url.protocol==="http:"||url.protocol==="https:") ? url.href : ""; }
  catch{ return ""; }
}

/* ---------- utilidades de interface compartilhadas ---------- */
function setDate(){ const el=document.getElementById("today"); if(el) el.textContent=new Intl.DateTimeFormat("pt-BR",{dateStyle:"full"}).format(new Date()); }

function setupMenu(){
  const b=document.getElementById("menuBtn"), n=document.getElementById("mainNav");
  if(!b||!n) return;
  b.setAttribute("aria-expanded","false");
  b.addEventListener("click",()=>{ const open=n.classList.toggle("open"); b.setAttribute("aria-expanded", String(open)); });
}

function setupCategoryFilter(selectEl,onChange){
  if(!selectEl) return;
  selectEl.innerHTML=`<option value="">Todas as categorias</option>`+CATEGORIES.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join("");
  selectEl.addEventListener("change", onChange);
}

function newsCardHTML(x){
  const img=safeUrl(x.image);
  return `<article class="card">
    ${img?`<img class="card-img" src="${esc(img)}" alt="${esc(x.title)}" loading="lazy">`:""}
    <div class="badge">${esc(x.category)} • FICÇÃO</div>
    <h3><a href="artigo.html?id=${encodeURIComponent(x.id)}">${esc(x.title)}</a></h3>
    <p>${esc(x.subtitle||"Uma notícia que não aconteceu, mas poderia ter acontecido em um universo muito pior.")}</p>
    <div class="meta">Por ${esc(x.author||"Redação")} • ${esc(x.date||"13 de setembro de 2026")} • 👁 ${x.views||0} • ♥ ${x.likes||0}</div>
  </article>`;
}

/* ---------- página inicial: destaque, laterais, grade, busca, filtro, paginação ---------- */
let visibleCount=8;
function renderHome(){
  const grid=document.getElementById("newsGrid");
  if(!grid) return;
  const heroSlot=document.getElementById("heroSlot");
  const sideSlot=document.getElementById("sideStack");
  const searchInput=document.getElementById("searchInput");
  const categorySelect=document.getElementById("categoryFilter");
  const loadMoreBtn=document.getElementById("loadMoreBtn");

  function currentList(){
    const q=(searchInput?.value||"").trim().toLowerCase();
    const cat=categorySelect?.value||"";
    return rankedNews().filter(x=>{
      const matchesQ=!q || x.title.toLowerCase().includes(q) || (x.subtitle||"").toLowerCase().includes(q);
      const matchesCat=!cat || x.category===cat;
      return matchesQ && matchesCat;
    });
  }

  function draw(){
    const list=currentList();
    if(heroSlot && sideSlot){
      const [hero,...rest]=list;
      heroSlot.innerHTML = hero ? `
        <div class="category">${esc(hero.category)} • FICÇÃO</div>
        <h1>${esc(hero.title)}</h1>
        <p class="dek">${esc(hero.subtitle||"")}</p>
        <div class="byline">Por ${esc(hero.author||"Redação do Absurd")} • ${esc(hero.date||"13 de setembro de 2026")}</div>
        <a class="read-more" href="artigo.html?id=${encodeURIComponent(hero.id)}">Ler reportagem →</a>
      ` : `<p class="notice">Nenhuma notícia encontrada para esta busca.</p>`;
      sideSlot.innerHTML = rest.slice(0,2).map(x=>`
        <article class="small-story">
          <div class="category">${esc(x.category)}</div>
          <h2><a href="artigo.html?id=${encodeURIComponent(x.id)}">${esc(x.title)}</a></h2>
          <p>${esc(x.subtitle||"")}</p>
        </article>`).join("");
      const gridItems=rest.slice(2, 2+visibleCount);
      grid.innerHTML = gridItems.length ? gridItems.map(newsCardHTML).join("") : `<p class="notice">Nenhuma outra notícia por aqui.</p>`;
      if(loadMoreBtn) loadMoreBtn.style.display = rest.length > 2+visibleCount ? "inline-block" : "none";
    }else{
      grid.innerHTML = list.slice(0,visibleCount).map(newsCardHTML).join("") || `<p class="notice">Nenhuma notícia encontrada.</p>`;
      if(loadMoreBtn) loadMoreBtn.style.display = list.length > visibleCount ? "inline-block" : "none";
    }
    renderRanking();
  }

  searchInput?.addEventListener("input", draw);
  setupCategoryFilter(categorySelect, draw);
  loadMoreBtn?.addEventListener("click", ()=>{ visibleCount+=8; draw(); });
  draw();
}

function renderRanking(){
  const el=document.getElementById("rankingList");
  if(!el) return;
  const top=rankedNews().slice(0,5);
  el.innerHTML = top.map((x,i)=>`<li><span>${String(i+1).padStart(2,"0")}</span><a href="artigo.html?id=${encodeURIComponent(x.id)}">${esc(x.title)}</a></li>`).join("");
}

function renderTicker(){
  const el=document.getElementById("tickerTrack"); if(!el) return;
  const headlines=[...rankedNews().slice(0,5).map(x=>x.title),"Especialistas confirmam que ninguém pediu esta pesquisa","Pombo nega envolvimento e pede privacidade"];
  el.textContent=headlines.join("   •   ");
}

const ABSURD_EVENTS=[
  "Um pombo foi visto esperando o ônibus certo. A cidade está em choque.",
  "Prefeitura inaugura uma faixa de pedestres exclusiva para quem está com pressa.",
  "Homem abre a geladeira pela quinta vez e finalmente encontra o que estava procurando: esperança.",
  "Cientistas descobrem que uma planta de escritório está julgando todos os funcionários.",
  "Elevador passa três andares e para apenas para pensar.",
  "Mercado anuncia promoção de silêncio: leve três minutos, pague com uma opinião.",
  "Especialistas recomendam não confiar em especialistas durante as próximas 48 horas."
];
function toast(msg){ const el=document.getElementById("toast"); if(!el) return; el.textContent=msg; el.classList.add("show"); clearTimeout(window.__toast); window.__toast=setTimeout(()=>el.classList.remove("show"),2800); }
function setupAbsurdCenter(){
  const event=document.getElementById("breakingEvent"), btn=document.getElementById("surpriseBtn"), score=document.getElementById("absurdScore"), fill=document.getElementById("meterFill");
  if(!event) return;
  const update=()=>{ const value=Math.floor(71+Math.random()*29); score.textContent=value+"%"; fill.style.width=value+"%"; event.textContent=ABSURD_EVENTS[Math.floor(Math.random()*ABSURD_EVENTS.length)]; };
  update(); btn?.addEventListener("click",()=>{update();toast("O departamento de realidade foi notificado.");});
  setInterval(update,15000);
}
function renderCategoryStats(){
  const el=document.getElementById("categoryStats"); if(!el) return;
  const counts={}; allNews().forEach(x=>counts[x.category]=(counts[x.category]||0)+1);
  el.innerHTML=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([k,v])=>`<button type="button" data-cat="${esc(k)}"><span>${esc(k)}</span><b>${v}</b></button>`).join("");
  el.addEventListener("click",e=>{const b=e.target.closest("button"); if(!b) return; const s=document.getElementById("categoryFilter"); if(s){s.value=b.dataset.cat;s.dispatchEvent(new Event("change"));window.scrollTo({top:document.querySelector(".search-bar")?.offsetTop||0,behavior:"smooth"});}});
}
function setupGlobalShortcuts(){
  document.addEventListener("keydown",e=>{ if(e.key==="/" && !/input|textarea|select/i.test(document.activeElement?.tagName||"")){e.preventDefault();document.getElementById("searchInput")?.focus();} if(e.key==="Escape") document.getElementById("searchInput")?.blur(); });
  document.querySelectorAll("[data-fake-ad]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();toast("Este anúncio também é fictício. Você quase comprou uma batata imaginária.");}));
}
function setupClock(){const el=document.getElementById("absurdClock"); if(!el) return; const tick=()=>{const d=new Date();el.textContent=`JORNALISMO • ${d.toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit",second:"2-digit"})}`};tick();setInterval(tick,1000);}

document.addEventListener("DOMContentLoaded",()=>{setDate();setupMenu();renderHome();renderTicker();renderRanking();renderCategoryStats();setupAbsurdCenter();setupGlobalShortcuts();setupClock();});


document.addEventListener('DOMContentLoaded',()=>{
 setDate(); setupMenu(); setupAccountUI();
 const clock=document.getElementById('absurdClock'); if(clock){setInterval(()=>clock.textContent=new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})+' • JORNALISMO 100% ABSURDO',1000);}
 const surprise=document.getElementById('surpriseBtn'); if(surprise) surprise.addEventListener('click',()=>{const events=ABSURD_EVENTS||[];const msg=events[Math.floor(Math.random()*events.length)]||'Um pombo acaba de pedir recesso.';const el=document.getElementById('breakingEvent');if(el)el.textContent=msg;});
 const search=document.getElementById('searchInput');if(search)document.addEventListener('keydown',e=>{if(e.key==='/'&&document.activeElement!==search){e.preventDefault();search.focus();}});
});

/* ---------- sincronização Supabase / conta ---------- */
function tdaClient(){ return typeof getTdaSupabase==='function' ? getTdaSupabase() : null; }
async function syncCurrentProfile(){
  const client=tdaClient();
  if(!client) return currentUser();
  const {data:{user}}=await client.auth.getUser();
  if(!user) return null;
  const {data:profile}=await client.from('profiles').select('*').eq('id',user.id).maybeSingle();
  if(profile){
    const local={id:user.id,email:user.email||'',name:profile.name,username:profile.username,bio:profile.bio||'',avatar:profile.avatar_url||'📰',avatar_url:profile.avatar_url||'',joined:profile.joined_at?new Intl.DateTimeFormat('pt-BR',{dateStyle:'long'}).format(new Date(profile.joined_at)):'',verified:!!user.email_confirmed_at};
    const users=readJSON('tdaUsers',[]),i=users.findIndex(x=>x.id===user.id); if(i>=0) users[i]={...users[i],...local}; else users.push(local); writeJSON('tdaUsers',users); setCurrentUser(local); return local;
  }
  return currentUser();
}
async function upsertProfileRemote(profile){
  const client=tdaClient(); if(!client) return {ok:false,error:'Supabase não configurado.'};
  const payload={id:profile.id,name:profile.name,username:profile.username,bio:profile.bio||'',avatar_url:profile.avatar_url||null};
  const {data,error}=await client.from('profiles').upsert(payload).select().single();
  if(error) return {ok:false,error:error.message};
  return {ok:true,data};
}
async function deleteArticleEverywhere(item){
  const me=currentUser(); if(!me || item.authorUsername!==me.username) return {ok:false,error:'Você só pode apagar suas próprias publicações.'};
  const arr=getCommunity().filter(x=>x.id!==item.id); saveCommunity(arr);
  const client=tdaClient();
  if(client && item.remoteId){
    const {error}=await client.from('articles').delete().eq('id',item.remoteId).eq('author_id',me.id);
    if(error) return {ok:false,error:error.message};
  }
  const counts=getLikeCounts(); delete counts[item.id]; writeJSON('tdaLikeCounts',counts);
  const comments=readJSON('tdaComments',{}); delete comments[item.id]; writeJSON('tdaComments',comments);
  return {ok:true};
}
